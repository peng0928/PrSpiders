from PrSpider.PrSpiders import PrSpiders

